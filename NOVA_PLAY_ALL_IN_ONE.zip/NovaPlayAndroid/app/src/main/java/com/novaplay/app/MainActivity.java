package com.novaplay.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Color;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.content.ContentResolver;
import android.content.pm.ActivityInfo;
import android.webkit.JavascriptInterface;
import android.view.View;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 7314;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(0);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.addJavascriptInterface(new PlayerBridge(), "NovaPlayNative");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                callback.onReceiveValue(null);
                return false;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }


    private class PlayerBridge {
        @JavascriptInterface public String getChannels() {
            HttpURLConnection connection = null;
            try {
                URL url = new URL("https://nova-play-api.ss1993199306.workers.dev/api/channels");
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setInstanceFollowRedirects(true);
                connection.setConnectTimeout(20000);
                connection.setReadTimeout(20000);
                connection.setUseCaches(false);
                connection.setRequestProperty("Accept", "application/json, text/plain, */*");
                connection.setRequestProperty("Accept-Encoding", "identity");
                connection.setRequestProperty("Cache-Control", "no-cache");
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");

                int status = connection.getResponseCode();
                InputStream input = (status >= 200 && status < 400)
                    ? connection.getInputStream() : connection.getErrorStream();
                String contentType = connection.getContentType();
                String finalUrl = connection.getURL().toString();
                if (input == null) {
                    return errorJson("HTTP " + status + " | Content-Type=" + contentType + " | URL=" + finalUrl);
                }
                StringBuilder result = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) result.append(line).append('\n');
                }
                String body = result.toString().trim();
                if (status < 200 || status >= 300) {
                    return errorJson("HTTP " + status + " | Content-Type=" + contentType + " | URL=" + finalUrl + " | BODY=" + preview(body));
                }
                try {
                    org.json.JSONObject json = new org.json.JSONObject(body);
                    if (!json.has("success") || !json.has("channels")) {
                        return errorJson("JSON غير متوقع | Content-Type=" + contentType + " | URL=" + finalUrl + " | BODY=" + preview(body));
                    }
                } catch (Exception invalidJson) {
                    return errorJson("الرد ليس JSON صالحًا | Content-Type=" + contentType + " | URL=" + finalUrl + " | BODY=" + preview(body));
                }
                return body;
            } catch (Exception e) {
                return errorJson(e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage()));
            } finally {
                if (connection != null) connection.disconnect();
            }
        }

        private String preview(String body) {
            if (body == null) return "";
            String clean = body.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ');
            return clean.length() > 180 ? clean.substring(0, 180) : clean;
        }

        private String errorJson(String message) {
            return "{\"success\":false,\"error\":" + org.json.JSONObject.quote(message) + ",\"channels\":[]}";
        }

        @JavascriptInterface public void enterPlayerMode() {
            runOnUiThread(() -> {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            });
        }
        @JavascriptInterface public void openExternalPlayer(String streamUrl, String streamName) {
            runOnUiThread(() -> {
                try {
                    Uri uri = Uri.parse(streamUrl);
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(uri, "video/*");
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    Intent chooser = Intent.createChooser(intent, "اختر مشغل الفيديو (مثل iMPlayer Mobile)");
                    startActivity(chooser);
                } catch (Exception e) {
                    android.widget.Toast.makeText(MainActivity.this,
                        "لم يتم العثور على مشغل متوافق. تأكد من تثبيت iMPlayer Mobile.",
                        android.widget.Toast.LENGTH_LONG).show();
                }
            });
        }
        @JavascriptInterface public void exitPlayerMode() {
            runOnUiThread(() -> {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri picked = data.getData();
                String name = getDisplayName(picked);
                if (name != null && name.toLowerCase().endsWith(".zip")) {
                    importZipPlaylist(picked);
                    results = null;
                } else {
                    results = new Uri[]{picked};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }


    private String getDisplayName(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) { }
        finally { if (cursor != null) cursor.close(); }
        return uri.getLastPathSegment();
    }

    private void importZipPlaylist(Uri uri) {
        new Thread(() -> {
            StringBuilder merged = new StringBuilder();
            int files = 0;
            try (InputStream raw = getContentResolver().openInputStream(uri);
                 ZipInputStream zip = new ZipInputStream(raw, StandardCharsets.UTF_8)) {
                ZipEntry entry;
                byte[] buffer = new byte[8192];
                while ((entry = zip.getNextEntry()) != null) {
                    String name = entry.getName();
                    String lower = name.toLowerCase();
                    // Import only the actual channel playlists, not repository tests or docs.
                    if (!entry.isDirectory() && name.matches("(?i)(.*/)?streams/[^/]+\\.m3u8?")) {
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        int n;
                        while ((n = zip.read(buffer)) > 0) out.write(buffer, 0, n);
                        String content = out.toString(StandardCharsets.UTF_8.name());
                        if (!content.trim().isEmpty()) {
                            merged.append("\n").append(content).append("\n");
                            files++;
                        }
                    }
                    zip.closeEntry();
                }
                final String playlist = merged.toString();
                final int count = files;
                runOnUiThread(() -> {
                    if (playlist.trim().isEmpty()) {
                        webView.evaluateJavascript("window.showNativeImportError && window.showNativeImportError('لم أجد ملفات M3U داخل ZIP.');", null);
                    } else {
                        webView.evaluateJavascript("window.importM3UFromNative && window.importM3UFromNative(" + org.json.JSONObject.quote(playlist) + "," + count + ");", null);
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> webView.evaluateJavascript("window.showNativeImportError && window.showNativeImportError('تعذر فتح ملف ZIP. جرّب فك الضغط واختيار ملف M3U.');", null));
            }
        }).start();
    }

    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("(function(){var m=document.getElementById('modal');if(m&&m.classList.contains('open')){m.classList.remove('open');return 'modal';}var p=document.getElementById('player');if(p&&p.classList.contains('show')){var v=document.getElementById('video');v.pause();v.removeAttribute('src');v.load();p.classList.remove('show','fullscreen');if(window.NovaPlayNative)NovaPlayNative.exitPlayerMode();return 'player';}return 'none';})()", value -> { if ("\"none\"".equals(value)) finish(); });
        else super.onBackPressed();
    }
}
