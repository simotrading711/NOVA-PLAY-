const KEY = 'channels-v1';
const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store'
};
const json = (data, status=200) => new Response(JSON.stringify(data), {status, headers:cors});
const adminPage = `<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>NOVA PLAY إدارة القنوات</title><style>body{margin:0;background:#080d1a;color:#eef3ff;font-family:Arial,sans-serif;padding:18px}.wrap{max-width:760px;margin:auto}h1{color:#a99aff}input,button{box-sizing:border-box;font:inherit;border-radius:10px;padding:12px;border:1px solid #33415f}input{width:100%;margin:6px 0 12px;background:#101a2e;color:white}button{background:#7047ff;color:white;border:0;margin:4px;cursor:pointer}.card{background:#111a2c;padding:16px;border-radius:14px;margin:12px 0}.muted{color:#aebbd2}.item{border-top:1px solid #2a3650;padding:12px 0;overflow-wrap:anywhere}.danger{background:#b62d48}</style><div class="wrap"><h1>NOVA PLAY — إدارة القنوات</h1><p class="muted">تُحفظ القنوات في Cloudflare KV. لا تشارك رمز الإدارة مع أحد.</p><section class="card"><label>رمز الإدارة</label><input id="token" type="password" placeholder="أدخل رمز الإدارة الذي أنشأته في Cloudflare"><button onclick="saveToken()">حفظ على هذا الجهاز</button><button onclick="load()">تحديث القنوات</button><div id="msg" class="muted"></div></section><section class="card"><h3>إضافة قناة</h3><label>اسم القناة</label><input id="name" placeholder="مثال: قناة رياضية"><label>التصنيف</label><input id="category" placeholder="رياضة"><label>رابط البث المصرح لك باستخدامه</label><input id="url" dir="ltr" placeholder="https://example.com/live.m3u8"><label>رابط الشعار (اختياري)</label><input id="logo" dir="ltr" placeholder="https://example.com/logo.png"><button onclick="add()">إضافة القناة</button></section><section class="card"><h3>القنوات المحفوظة</h3><div id="list">اضغط تحديث القنوات</div></section></div><script>const $=id=>document.getElementById(id);$('token').value=sessionStorage.getItem('nova_admin_token')||'';function saveToken(){sessionStorage.setItem('nova_admin_token',$('token').value.trim());$('msg').textContent='تم حفظ الرمز لهذه الجلسة على هذا الجهاز.'}async function call(method='GET',body){let token=$('token').value.trim();if(!token)throw Error('أدخل رمز الإدارة أولاً');let r=await fetch('/api/admin/channels',{method,headers:{'Content-Type':'application/json','Authorization':'Bearer '+token},body:body?JSON.stringify(body):undefined,cache:'no-store'});let j=await r.json().catch(()=>({}));if(!r.ok||!j.success)throw Error(j.error||'فشل الطلب '+r.status);return j}async function load(){try{let j=await call();$('list').innerHTML='';if(!j.channels.length){$('list').textContent='لا توجد قنوات محفوظة بعد.';return}j.channels.forEach(c=>{let d=document.createElement('div');d.className='item';let t=document.createElement('div');t.textContent=c.name+' — '+c.category+' | '+c.url;d.appendChild(t);let b=document.createElement('button');b.className='danger';b.textContent='حذف';b.onclick=async()=>{if(!confirm('حذف '+c.name+'؟'))return;try{await call('DELETE',{id:c.id});await load()}catch(e){alert(e.message)}};d.appendChild(b);$('list').appendChild(d)});$('msg').textContent='تم جلب '+j.channels.length+' قناة.'}catch(e){$('msg').textContent=e.message}}async function add(){let name=$('name').value.trim(),category=$('category').value.trim()||'الكل',url=$('url').value.trim(),logo=$('logo').value.trim();if(!name||!url){alert('أدخل اسم القناة ورابط البث');return}if(!/^https:\/\//i.test(url)){alert('استخدم رابط HTTPS');return}try{await call('POST',{name,category,url,logo});$('name').value='';$('category').value='';$('url').value='';$('logo').value='';await load()}catch(e){alert(e.message)}}load();</script></html>`;
export default {
 async fetch(request, env) {
  const url = new URL(request.url);
  if (request.method === 'OPTIONS') return new Response(null,{status:204,headers:cors});
  if (url.pathname === '/' || url.pathname === '/admin') return new Response(adminPage,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'}});
  if (!env.CHANNELS_KV) return json({success:false,error:'KV binding CHANNELS_KV is not configured',channels:[]},500);
  if (url.pathname === '/api/channels' && request.method === 'GET') {
    try { const channels = await env.CHANNELS_KV.get(KEY,'json') || []; return json({success:true,channels}); }
    catch(e) { return json({success:false,error:'Unable to read channels',channels:[]},500); }
  }
  if (url.pathname === '/api/admin/channels') {
    const expected = env.CHANNEL_ADMIN_TOKEN;
    const auth = request.headers.get('Authorization') || '';
    if (!expected || auth !== 'Bearer '+expected) return json({success:false,error:'رمز الإدارة غير صحيح'},401);
    let channels = await env.CHANNELS_KV.get(KEY,'json') || [];
    if (!Array.isArray(channels)) channels=[];
    if (request.method === 'GET') return json({success:true,channels});
    let body; try { body=await request.json(); } catch { return json({success:false,error:'JSON غير صالح'},400); }
    if (request.method === 'POST') {
      const name=String(body.name||'').trim(), stream=String(body.url||'').trim();
      if (!name || !/^https:\/\//i.test(stream)) return json({success:false,error:'أدخل اسم القناة ورابط HTTPS صالحًا'},400);
      const id=crypto.randomUUID(); channels.push({id,name,category:String(body.category||'الكل').trim(),url:stream,logo:String(body.logo||'').trim()});
      await env.CHANNELS_KV.put(KEY,JSON.stringify(channels)); return json({success:true,channels});
    }
    if (request.method === 'DELETE') {
      const before=channels.length; channels=channels.filter(c=>String(c.id)!==String(body.id));
      if (channels.length===before) return json({success:false,error:'القناة غير موجودة'},404);
      await env.CHANNELS_KV.put(KEY,JSON.stringify(channels)); return json({success:true,channels});
    }
  }
  return json({success:false,error:'Not found'},404);
 }
};
