# NOVA PLAY — نسخة نقل API إلى Cloudflare Workers

هذه النسخة تعالج صفحة الحماية HTML من InfinityFree بنقل واجهة القنوات إلى Cloudflare Workers + KV. لم يتم نشرها على حسابك ولم يتم اختبار APK مبني؛ يجب إكمال خطوات النشر أدناه أولاً.

## 1) نشر API من الهاتف
1. افتح https://dash.cloudflare.com/ وأنشئ حسابًا أو سجّل الدخول.
2. من القائمة افتح **Workers & Pages** ثم أنشئ Worker جديدًا باسم مثل `nova-play-api`.
3. افتح محرر الكود للـ Worker، واستبدل محتواه بالكامل بمحتوى الملف `worker.js` الموجود في هذا المشروع، ثم اضغط **Deploy**.
4. من صفحة Worker افتح **Settings → Bindings**، أضف **KV namespace binding** باسم المتغير `CHANNELS_KV`. أنشئ namespace جديدًا باسم `NOVA_PLAY_CHANNELS` واربطه بهذا المتغير، ثم احفظ/أعد النشر إذا طُلب منك.
5. من **Settings → Variables and Secrets** أضف Secret باسم `CHANNEL_ADMIN_TOKEN`، واجعل قيمته كلمة طويلة عشوائية لا تشاركها مع أحد. احفظ وأعد النشر.
6. افتح رابط Worker الذي ينتهي غالبًا بـ `.workers.dev`. الصفحة الرئيسية هي لوحة إدارة القنوات، والرابط `/api/channels` يجب أن يعرض JSON مثل `{"success":true,"channels":[]}`.
7. افتح لوحة الإدارة، أدخل رمز `CHANNEL_ADMIN_TOKEN` الذي أنشأته، ثم أضف القنوات. استخدم فقط روابط البث التي تملك حق استخدامها.

## 2) إعداد تطبيق Android
ابحث في ملفات التطبيق عن `https://nova-play-api.ss1993199306.workers.dev/api/channels` واستبدل `YOUR-WORKER` باسم Worker الفعلي الذي أنشأته. يظهر الرابط في ملفي:
- `NovaPlayAndroid/app/src/main/java/com/novaplay/app/MainActivity.java`
- `NovaPlayAndroid/app/src/main/assets/index.html`

بعد استبدال الرابط، ارفع محتويات هذا المشروع إلى جذر مستودع GitHub (يجب أن يظهر مجلد `.github` في جذر المستودع، وليس رفع ZIP كملف منفرد)، ثم افتح **Actions → Build NOVA PLAY APK → Run workflow**. نزّل Artifact باسم `NOVA-PLAY-debug-apk` وثبّت ملف APK الموجود بداخله.

## نقاط مهمة
- لا تضع `CHANNEL_ADMIN_TOKEN` داخل التطبيق أو ملفات Android؛ هو سر للإدارة فقط.
- API العامة للقراءة لا تحتاج رمزًا، أما إضافة/حذف القنوات فتتطلب الرمز.
- هذه النسخة تنقل API القنوات فقط. وظائف الحسابات والاشتراكات في `index.html` ما زالت تحتاج خادمًا منفصلًا وقاعدة بيانات إذا أردت استخدامها.
- لم يتم بناء APK أو اختبار نشر Cloudflare من هنا؛ تحقق من رابط `/api/channels` قبل بناء التطبيق.
